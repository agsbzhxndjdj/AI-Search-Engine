from flask import Flask, request, jsonify
from transformers import pipeline
import requests
from bs4 import BeautifulSoup

app = Flask(__name__)

# تحميل نموذج ذكاء اصطناعي للإجابة
qa_model = pipeline("question-answering", model="distilbert-base-uncased")

# وظيفة البحث في Google
def crawl_web(query):
    url = f"https://www.google.com/search?q={query}"
    headers = {"User-Agent": "Mozilla/5.0"}
    response = requests.get(url, headers=headers)
    soup = BeautifulSoup(response.text, "html.parser")

    results = []
    for g in soup.find_all('div', class_='tF2Cxc'):
        title = g.find('h3').text if g.find('h3') else "بدون عنوان"
        link = g.a['href'] if g.a else "#"
        results.append({"title": title, "link": link})

    return results

# API للبحث
@app.route('/search', methods=['GET'])
def search():
    query = request.args.get('q')
    if not query:
        return jsonify({"error": "يرجى إدخال كلمة البحث"}), 400

    results = crawl_web(query)
    if results:
        return jsonify(results)

    # إذا لم يتم العثور على نتائج، يتم توليد إجابة ذكية
    answer = qa_model(question=query, context="لم يتم العثور على إجابة مباشرة، لكن هذه معلومات تقريبية.")
    return jsonify({"generated_answer": answer['answer']})

# تشغيل السيرفر
if __name__ == '__main__':
    app.run(host='0.0.0.0', port=10000)